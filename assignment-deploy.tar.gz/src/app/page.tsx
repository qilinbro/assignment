import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, GraduationCap, UserCircle, LayoutDashboard } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold">作业管理系统</h1>
            </div>
            <div className="flex gap-4">
              <Link href="/login">
                <Button variant="outline">登录</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            作业提交与助教批改系统
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            一站式管理学生作业提交、助教分配与批改流程的综合平台。
          </p>
        </div>

        {/* Role Selection Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Admin Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mb-4">
                <LayoutDashboard className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle>管理员</CardTitle>
              <CardDescription>
                管理作业、查看统计数据，统筹整个批改流程
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/admin">
                <Button className="w-full">进入控制台</Button>
              </Link>
            </CardContent>
          </Card>

          {/* TA Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center mb-4">
                <GraduationCap className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <CardTitle>助教</CardTitle>
              <CardDescription>
                查看分配的提交、批改作业并给出反馈
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/ta">
                <Button className="w-full" variant="secondary">
                  进入控制台
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Student Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center mb-4">
                <UserCircle className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <CardTitle>学生</CardTitle>
              <CardDescription>
                提交作业、查看反馈并管理重新提交
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/student">
                <Button className="w-full" variant="secondary">
                  进入控制台
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Features Section */}
        <div className="mt-24 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-center mb-12">核心功能</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-xs">✓</span>
                </div>
                <div>
                  <h4 className="font-semibold">助教随机分配</h4>
                  <p className="text-sm text-muted-foreground">
                    服务端随机为每份提交分配多名助教
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-xs">✓</span>
                </div>
                <div>
                  <h4 className="font-semibold">灵活配置</h4>
                  <p className="text-sm text-muted-foreground">
                    按作业配置助教数量与可用性
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-xs">✓</span>
                </div>
                <div>
                  <h4 className="font-semibold">重新提交流程</h4>
                  <p className="text-sm text-muted-foreground">
                    专属的学生重新提交通道，并保留完整历史记录
                  </p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-xs">✓</span>
                </div>
                <div>
                  <h4 className="font-semibold">基于角色的权限控制</h4>
                  <p className="text-sm text-muted-foreground">
                    为所有角色提供安全的认证与授权
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-xs">✓</span>
                </div>
                <div>
                  <h4 className="font-semibold">实时进度</h4>
                  <p className="text-sm text-muted-foreground">
                    跟踪批改进度与提交统计数据
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-xs">✓</span>
                </div>
                <div>
                  <h4 className="font-semibold">文件上传支持</h4>
                  <p className="text-sm text-muted-foreground">
                    支持图片、PDF 和文档上传，并带预览
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm mt-24">
        <div className="container mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
          <p>作业提交与助教批改系统。基于 Next.js、TypeScript 和 shadcn/ui 构建。</p>
        </div>
      </footer>
    </div>
  );
}
