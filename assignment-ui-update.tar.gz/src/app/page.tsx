import Link from "next/link";
import { BookOpen, LogIn, Shield, GraduationCap, UserCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold">作业管理系统</h1>
            </div>
            <Link href="/login">
              <Button>
                <LogIn className="h-4 w-4 mr-2" />
                登录
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <main className="container mx-auto px-4 py-24 text-center">
        <h2 className="text-4xl font-bold mb-4">
          作业提交与助教批改系统
        </h2>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
          一站式管理学生作业提交、助教分配与批改流程的综合平台。
        </p>

        <Link href="/login">
          <Button size="lg" className="px-8">
            <LogIn className="h-5 w-5 mr-2" />
            进入系统
          </Button>
        </Link>

        {/* 角色简介 */}
        <div className="mt-20 grid md:grid-cols-3 gap-6 max-w-4xl mx-auto text-left">
          <div className="flex items-start gap-3 p-5 rounded-lg bg-white/60 dark:bg-slate-800/60 border">
            <Shield className="h-6 w-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold mb-1">管理员</h3>
              <p className="text-sm text-muted-foreground">
                发布作业、查看统计、统筹批改流程
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-5 rounded-lg bg-white/60 dark:bg-slate-800/60 border">
            <GraduationCap className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold mb-1">助教</h3>
              <p className="text-sm text-muted-foreground">
                查看分配的提交、批改作业并给出反馈
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-5 rounded-lg bg-white/60 dark:bg-slate-800/60 border">
            <UserCircle className="h-6 w-6 text-purple-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold mb-1">学生</h3>
              <p className="text-sm text-muted-foreground">
                提交作业、查看反馈、管理重新提交
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm mt-24">
        <div className="container mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
          <p>作业提交与助教批改系统。基于 Next.js、TypeScript 和 shadcn/ui 构建。</p>
        </div>
      </footer>
    </div>
  );
}
